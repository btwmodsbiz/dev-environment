package org.lwjgl.util.generator;

/**
 *
 * @author elias_naur <elias_naur@users.sourceforge.net>
 * @version $Revision: 2286 $
 * $Id: BufferKind.java 2286 2006-03-23 19:32:21Z matzon $
 */

public enum BufferKind {
	UnpackPBO,
	PackPBO,
	ElementVBO,
	ArrayVBO
}
