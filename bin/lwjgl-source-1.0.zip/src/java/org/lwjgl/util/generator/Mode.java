package org.lwjgl.util.generator;

public enum Mode {
	BUFFEROBJECT,
	AUTOS,
	NORMAL
}
