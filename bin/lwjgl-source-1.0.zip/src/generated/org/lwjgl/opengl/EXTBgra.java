/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class EXTBgra {
	public static final int GL_BGR_EXT = 0x80e0;
	public static final int GL_BGRA_EXT = 0x80e1;

	private EXTBgra() {
	}

}
