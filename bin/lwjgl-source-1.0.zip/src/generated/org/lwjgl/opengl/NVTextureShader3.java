/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVTextureShader3 {
	public static final int GL_OFFSET_PROJECTIVE_TEXTURE_2D_NV = 0x8850;
	public static final int GL_OFFSET_PROJECTIVE_TEXTURE_2D_SCALE_NV = 0x8851;
	public static final int GL_OFFSET_PROJECTIVE_TEXTURE_RECTANGLE_NV = 0x8852;
	public static final int GL_OFFSET_PROJECTIVE_TEXTURE_RECTANGLE_SCALE_NV = 0x8853;
	public static final int GL_OFFSET_HILO_TEXTURE_2D_NV = 0x8854;
	public static final int GL_OFFSET_HILO_TEXTURE_RECTANGLE_NV = 0x8855;
	public static final int GL_OFFSET_HILO_PROJECTIVE_TEXTURE_2D_NV = 0x8856;
	public static final int GL_OFFSET_HILO_PROJECTIVE_TEXTURE_RECTANGLE_NV = 0x8857;
	public static final int GL_DEPENDENT_HILO_TEXTURE_2D_NV = 0x8858;
	public static final int GL_DEPENDENT_RGB_TEXTURE_3D_NV = 0x8859;
	public static final int GL_DEPENDENT_RGB_TEXTURE_CUBE_MAP_NV = 0x885a;
	public static final int GL_DOT_PRODUCT_PASS_THROUGH_NV = 0x885b;
	public static final int GL_DOT_PRODUCT_TEXTURE_1D_NV = 0x885c;
	public static final int GL_DOT_PRODUCT_AFFINE_DEPTH_REPLACE_NV = 0x885d;
	public static final int GL_HILO8_NV = 0x885e;
	public static final int GL_SIGNED_HILO8_NV = 0x885f;
	public static final int GL_FORCE_BLUE_TO_ONE_NV = 0x8860;

	private NVTextureShader3() {
	}

}
