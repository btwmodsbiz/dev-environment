/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class EXTStencilWrap {
	public static final int GL_INCR_WRAP_EXT = 0x8507;
	public static final int GL_DECR_WRAP_EXT = 0x8508;

	private EXTStencilWrap() {
	}

}
