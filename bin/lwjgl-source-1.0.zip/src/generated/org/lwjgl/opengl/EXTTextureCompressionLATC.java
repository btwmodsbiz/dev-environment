/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class EXTTextureCompressionLATC {
	/**
	 * Accepted by the &lt;internalformat&gt; parameter of TexImage2D,
	 * CopyTexImage2D, and CompressedTexImage2D and the &lt;format&gt; parameter
	 * of CompressedTexSubImage2D:
	 */
	public static final int GL_COMPRESSED_LUMINANCE_LATC1_EXT = 0x8c70;
	public static final int GL_COMPRESSED_SIGNED_LUMINANCE_LATC1_EXT = 0x8c71;
	public static final int GL_COMPRESSED_LUMINANCE_ALPHA_LATC2_EXT = 0x8c72;
	public static final int GL_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2_EXT = 0x8c73;

	private EXTTextureCompressionLATC() {
	}

}
