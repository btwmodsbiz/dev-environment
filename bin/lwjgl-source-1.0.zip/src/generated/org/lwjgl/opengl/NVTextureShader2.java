/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVTextureShader2 {
	public static final int GL_DOT_PRODUCT_TEXTURE_3D_NV = 0x86ef;
	public static final int GL_HILO_NV = 0x86f4;
	public static final int GL_DSDT_NV = 0x86f5;
	public static final int GL_DSDT_MAG_NV = 0x86f6;
	public static final int GL_DSDT_MAG_VIB_NV = 0x86f7;
	public static final int GL_UNSIGNED_INT_S8_S8_8_8_NV = 0x86da;
	public static final int GL_UNSIGNED_INT_8_8_S8_S8_REV_NV = 0x86db;
	public static final int GL_SIGNED_RGBA_NV = 0x86fb;
	public static final int GL_SIGNED_RGBA8_NV = 0x86fc;
	public static final int GL_SIGNED_RGB_NV = 0x86fe;
	public static final int GL_SIGNED_RGB8_NV = 0x86ff;
	public static final int GL_SIGNED_LUMINANCE_NV = 0x8701;
	public static final int GL_SIGNED_LUMINANCE8_NV = 0x8702;
	public static final int GL_SIGNED_LUMINANCE_ALPHA_NV = 0x8703;
	public static final int GL_SIGNED_LUMINANCE8_ALPHA8_NV = 0x8704;
	public static final int GL_SIGNED_ALPHA_NV = 0x8705;
	public static final int GL_SIGNED_ALPHA8_NV = 0x8706;
	public static final int GL_SIGNED_INTENSITY_NV = 0x8707;
	public static final int GL_SIGNED_INTENSITY8_NV = 0x8708;
	public static final int GL_SIGNED_RGB_UNSIGNED_ALPHA_NV = 0x870c;
	public static final int GL_SIGNED_RGB8_UNSIGNED_ALPHA8_NV = 0x870d;
	public static final int GL_HILO16_NV = 0x86f8;
	public static final int GL_SIGNED_HILO_NV = 0x86f9;
	public static final int GL_SIGNED_HILO16_NV = 0x86fa;
	public static final int GL_DSDT8_NV = 0x8709;
	public static final int GL_DSDT8_MAG8_NV = 0x870a;
	public static final int GL_DSDT_MAG_INTENSITY_NV = 0x86dc;
	public static final int GL_DSDT8_MAG8_INTENSITY8_NV = 0x870b;

	private NVTextureShader2() {
	}

}
